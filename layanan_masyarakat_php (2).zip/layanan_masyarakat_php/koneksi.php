<?php
// Koneksi MySQL (ubah sesuai environment XAMPP/Laragon)
// Default: host=localhost, user=root, password='', database=layanan_masyarakat
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'layanan_masyarakat';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_errno) {
    die("Koneksi gagal: " . $conn->connect_error);
}
$conn->set_charset('utf8mb4');
