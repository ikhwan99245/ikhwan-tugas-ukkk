<?php
require "config.php";

// =============== HAPUS DATA ===============
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM penduduk WHERE id='$id'");
    header("Location: penduduk.php");
    exit;
}

// =============== TAMBAH DATA ===============
if (isset($_POST['simpan'])) {
    $nama   = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telp   = $_POST['telp'];

    mysqli_query($conn, "INSERT INTO penduduk(nama, alamat, telp) 
                         VALUES('$nama','$alamat','$telp')");

    header("Location: penduduk.php");
    exit;
}

// =============== UPDATE DATA ===============
if (isset($_POST['update'])) {
    $id     = $_POST['id'];
    $nama   = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telp   = $_POST['telp'];

    mysqli_query($conn, "UPDATE penduduk 
                         SET nama='$nama', alamat='$alamat', telp='$telp' 
                         WHERE id='$id'");

    header("Location: penduduk.php");
    exit;
}

// =============== AMBIL DATA UNTUK EDIT ===============
$edit = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM penduduk WHERE id='$id'"));
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>CRUD Penduduk 1 File</title>
</head>
<body>

<h2>Data Penduduk</h2>

<table border="1" cellpadding="8">
<tr>
    <th>No</th>
    <th>Nama</th>
    <th>Alamat</th>
    <th>Telp</th>
    <th>Aksi</th>
</tr>

<?php
$no = 1;
$data = mysqli_query($conn, "SELECT * FROM penduduk");
while ($row = mysqli_fetch_assoc($data)) {
?>
<tr>
    <td><?= $no++; ?></td>
    <td><?= $row['nama']; ?></td>
    <td><?= $row['alamat']; ?></td>
    <td><?= $row['telp']; ?></td>
    <td>
        <a href="penduduk.php?edit=<?= $row['id']; ?>">Edit</a> |
        <a href="penduduk.php?hapus=<?= $row['id']; ?>" onclick="return confirm('Yakin?')">Hapus</a>
    </td>
</tr>
<?php } ?>
</table>

<hr>

<!-- =============== FORM TAMBAH =============== -->
<?php if (!$edit) { ?>
<h3>Tambah Penduduk</h3>
<form method="POST">
    Nama:   <input type="text" name="nama" required><br><br>
    Alamat: <input type="text" name="alamat" required><br><br>
    Telp:   <input type="text" name="telp" required><br><br>
    <button type="submit" name="simpan">Simpan</button>
</form>

<?php } ?>

<!-- =============== FORM EDIT =============== -->
<?php if ($edit) { ?>
<h3>Edit Penduduk</h3>
<form method="POST">
    <input type="hidden" name="id" value="<?= $edit['id']; ?>">

    Nama:   <input type="text" name="nama" value="<?= $edit['nama']; ?>" required><br><br>
    Alamat: <input type="text" name="alamat" value="<?= $edit['alamat']; ?>" required><br><br>
    Telp:   <input type="text" name="telp" value="<?= $edit['telp']; ?>" required><br><br>
    
    <button type="submit" name="update">Update</button>
    <a href="penduduk.php">Batal</a>
</form>
<?php } ?>

</body>
</html>
