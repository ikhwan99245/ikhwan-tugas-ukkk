<?php
require_once 'koneksi.php';
// basic validation and prepared statement to prevent SQL injection
$nama = isset($_POST['nama'])? trim($_POST['nama']) : null;
$jenis = isset($_POST['jenis'])? trim($_POST['jenis']) : null;
$lokasi = isset($_POST['lokasi'])? trim($_POST['lokasi']) : null;
$deskripsi = isset($_POST['deskripsi'])? trim($_POST['deskripsi']) : null;
$kontak = isset($_POST['kontak'])? trim($_POST['kontak']) : null;

if(!$lokasi || !$deskripsi){
    header('Location: index.php?error=missing');
    exit;
}

$stmt = $conn->prepare("INSERT INTO laporan (nama, jenis, lokasi, deskripsi, kontak) VALUES (?, ?, ?, ?, ?)");
if(!$stmt){
    die('Prepare failed: ' . $conn->error);
}
$stmt->bind_param('sssss', $nama, $jenis, $lokasi, $deskripsi, $kontak);
$ok = $stmt->execute();
$stmt->close();
if($ok){
    header('Location: index.php?ok=lapor');
    exit;
} else {
    die('Gagal menyimpan laporan: ' . $conn->error);
}
