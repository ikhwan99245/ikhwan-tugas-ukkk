<?php
require_once 'koneksi.php';
// simple admin view: show laporan and relawan
// WARNING: This page has no authentication. Add auth for production.
$laporan_res = $conn->query("SELECT id,nama,jenis,lokasi,deskripsi,kontak,waktu FROM laporan ORDER BY waktu DESC");
$relawan_res = $conn->query("SELECT id,nama,kontak,waktu FROM relawan ORDER BY waktu DESC");
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin — Layanan Masyarakat</title>
  <style>
    body{font-family:Arial,Helvetica,sans-serif;background:#f3f6fb;color:#0b1220;margin:0;padding:20px}
    .container{max-width:1000px;margin:0 auto}
    .card{background:white;padding:16px;border-radius:10px;box-shadow:0 6px 20px rgba(2,6,23,0.06);margin-top:14px}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    td,th{padding:8px;border-bottom:1px solid #eef3f7;text-align:left}
    .danger{background:#fee2e2;color:#991b1b;padding:10px;border-radius:8px}
    a.btn{display:inline-block;padding:8px 12px;border-radius:8px;background:#ef4444;color:white;text-decoration:none}
  </style>
</head>
<body>
  <div class="container">
    <h1>Halaman Admin</h1>
    <div style="display:flex;gap:8px;margin-bottom:8px">
      <a class="btn" href="index.php">Kembali ke Forum</a>
      <a class="btn" href="?action=export">Ekspor Semua (JSON)</a>
      <a class="btn" href="?action=clear" onclick="return confirm('Hapus semua data?')">Hapus Semua</a>
    </div>

    <?php if(isset($_GET['msg'])): ?>
      <div class="card"><?php echo htmlspecialchars($_GET['msg']); ?></div>
    <?php endif; ?>

    <div class="card">
      <h2>Data Laporan</h2>
      <?php if($laporan_res->num_rows===0): ?>
        <div class="small muted">Belum ada laporan.</div>
      <?php else: ?>
        <table>
          <thead><tr><th>ID</th><th>Waktu</th><th>Nama</th><th>Kategori</th><th>Lokasi</th><th>Kontak</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php while($r = $laporan_res->fetch_assoc()): ?>
            <tr>
              <td><?php echo $r['id']; ?></td>
              <td class="small"><?php echo $r['waktu']; ?></td>
              <td><?php echo htmlspecialchars($r['nama']); ?></td>
              <td><?php echo htmlspecialchars($r['jenis']); ?></td>
              <td><?php echo htmlspecialchars($r['lokasi']); ?></td>
              <td><?php echo htmlspecialchars($r['kontak']); ?></td>
              <td>
                <a href="admin.php?delete_laporan=<?php echo $r['id']; ?>" onclick="return confirm('Hapus laporan ini?')">Hapus</a>
              </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

    <div class="card">
      <h2>Data Relawan</h2>
      <?php if($relawan_res->num_rows===0): ?>
        <div class="small muted">Belum ada pendaftar.</div>
      <?php else: ?>
        <table>
          <thead><tr><th>ID</th><th>Waktu</th><th>Nama</th><th>Kontak</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php while($v = $relawan_res->fetch_assoc()): ?>
            <tr>
              <td><?php echo $v['id']; ?></td>
              <td class="small"><?php echo $v['waktu']; ?></td>
              <td><?php echo htmlspecialchars($v['nama']); ?></td>
              <td><?php echo htmlspecialchars($v['kontak']); ?></td>
              <td><a href="admin.php?delete_relawan=<?php echo $v['id']; ?>" onclick="return confirm('Hapus pendaftar ini?')">Hapus</a></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
<?php

if(isset($_GET['delete_laporan'])){
    $id = (int)$_GET['delete_laporan'];

    $stmt = $conn->prepare("DELETE FROM laporan WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    
    header('Location: admin.php?msg=Laporan+terhapus');
    exit;
}

if(isset($_GET['delete_relawan'])){
    $id = (int)$_GET['delete_relawan'];

    $stmt = $conn->prepare("DELETE FROM relawan WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    
    header('Location: admin.php?msg=Pendaftar+terhapus');
    exit;
}

if(isset($_GET['action']) && $_GET['action'] == 'clear'){
    $conn->query("TRUNCATE TABLE laporan");
    $conn->query("TRUNCATE TABLE relawan");
    
    header('Location: admin.php?msg=Semua+data+telah+dihapus');
    exit;
}

if(isset($_GET['action']) && $_GET['action'] == 'export'){
    $out = [];
    
    $res1 = $conn->query("SELECT * FROM laporan");
    $res2 = $conn->query("SELECT * FROM relawan");
    
    $out['laporan'] = $res1 ? $res1->fetch_all(MYSQLI_ASSOC) : []; 
    $out['relawan'] = $res2 ? $res2->fetch_all(MYSQLI_ASSOC) : [];
    
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="export_layanan_masyarakat.json"');
    
    echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

?>
</body>
</html>
