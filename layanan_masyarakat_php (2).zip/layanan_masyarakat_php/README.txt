Petunjuk singkat menjalankan proyek (XAMPP/Laragon)
1. Letakkan folder 'layanan_masyarakat_php' ke dalam folder htdocs (XAMPP) atau www (Laragon).
2. Buka phpMyAdmin, jalankan file 'database.sql' untuk membuat database dan tabel:
   - Pilih tab SQL, paste atau upload database.sql, lalu eksekusi.
   - Atau buat database bernama 'layanan_masyarakat' secara manual.
3. Pastikan file koneksi.php sesuai (default: user=root, password kosong).
4. Akses http://localhost/layanan_masyarakat_php/index.php
5. Halaman admin: http://localhost/layanan_masyarakat_php/admin.php
Catatan keamanan: Ini adalah prototype — tambahkan autentikasi pada admin dan sanitasi file upload sebelum digunakan di produksi.
