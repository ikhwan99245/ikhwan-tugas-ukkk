<?php
require "config.php";

// =============== HAPIL DATA ===============
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM berita WHERE id='$id'");
    header("Location: berita.php");
    exit;
}

// =============== TAMBAH DATA ===============
if (isset($_POST['simpan'])) {
    $judul   = $_POST['judul'];
    $isi     = $_POST['isi'];
    $tanggal = $_POST['tanggal'];

    mysqli_query($conn, "INSERT INTO berita (judul, isi, tanggal)
                         VALUES('$judul','$isi','$tanggal')");

    header("Location: berita.php");
    exit;
}

// =============== UPDATE DATA ===============
if (isset($_POST['update'])) {
    $id      = $_POST['id'];
    $judul   = $_POST['judul'];
    $isi     = $_POST['isi'];
    $tanggal = $_POST['tanggal'];

    mysqli_query($conn, "UPDATE berita SET 
                        judul='$judul', 
                        isi='$isi', 
                        tanggal='$tanggal'
                        WHERE id='$id'");

    header("Location: berita.php");
    exit;
}

// =============== AMBIL DATA UNTUK EDIT ===============
$edit = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM berita WHERE id='$id'"));
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>CRUD Berita</title>
</head>
<body>

<h2>Data Berita</h2>

<table border="1" cellpadding="8">
<tr>
    <th>No</th>
    <th>Judul</th>
    <th>Isi</th>
    <th>Tanggal</th>
    <th>Aksi</th>
</tr>

<?php
$no = 1;
$data = mysqli_query($conn, "SELECT * FROM berita ORDER BY tanggal DESC");
while ($row = mysqli_fetch_assoc($data)) {
?>
<tr>
    <td><?= $no++; ?></td>
    <td><?= $row['judul']; ?></td>
    <td><?= substr($row['isi'], 0, 50); ?>...</td>
    <td><?= $row['tanggal']; ?></td>
    <td>
        <a href="berita.php?edit=<?= $row['id']; ?>">Edit</a> |
        <a href="berita.php?hapus=<?= $row['id']; ?>" onclick="return confirm('Yakin?')">Hapus</a>
    </td>
</tr>
<?php } ?>
</table>

<hr>

<!-- =============== FORM TAMBAH =============== -->
<?php if (!$edit) { ?>
<h3>Tambah Berita</h3>
<form method="POST">
    Judul:   <input type="text" name="judul" required><br><br>
    Isi:     <textarea name="isi" rows="5" cols="40" required></textarea><br><br>
    Tanggal: <input type="date" name="tanggal" required><br><br>

    <button type="submit" name="simpan">Simpan</button>
</form>

<?php } ?>

<!-- =============== FORM EDIT =============== -->
<?php if ($edit) { ?>
<h3>Edit Berita</h3>
<form method="POST">
    <input type="hidden" name="id" value="<?= $edit['id']; ?>">

    Judul:   <input type="text" name="judul" value="<?= $edit['judul']; ?>" required><br><br>
    Isi:     <textarea name="isi" rows="5" cols="40" required><?= $edit['isi']; ?></textarea><br><br>
    Tanggal: <input type="date" name="tanggal" value="<?= $edit['tanggal']; ?>" required><br><br>

    <button type="submit" name="update">Update</button>
    <a href="berita.php">Batal</a>
</form>
<?php } ?>

</body>
</html>
