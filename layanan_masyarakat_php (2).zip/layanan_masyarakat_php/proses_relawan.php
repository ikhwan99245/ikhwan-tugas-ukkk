<?php
require_once 'koneksi.php';

$nama = isset($_POST['nama'])? trim($_POST['nama']) : null;
$kontak = isset($_POST['kontak'])? trim($_POST['kontak']) : null;

if(!$nama || !$kontak){
    header('Location: index.php?error=missing_vol');
    exit;
}

$stmt = $conn->prepare("INSERT INTO relawan (nama, kontak) VALUES (?, ?)");
if(!$stmt){
    die('Prepare failed: ' . $conn->error);
}
$stmt->bind_param('ss', $nama, $kontak);
$ok = $stmt->execute();
$stmt->close();
if($ok){
    header('Location: index.php?ok=vol');
    exit;
} else {
    die('Gagal menyimpan relawan: ' . $conn->error);
}
