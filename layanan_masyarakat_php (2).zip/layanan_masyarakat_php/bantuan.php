<?php
require "config.php";

// =============== HAPUS DATA ===============
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM bantuan WHERE id='$id'");
    header("Location: bantuan.php");
    exit;
}

// =============== TAMBAH DATA ===============
if (isset($_POST['simpan'])) {
    $nama       = $_POST['nama_bantuan'];
    $penerima   = $_POST['penerima'];
    $tanggal    = $_POST['tanggal'];

    mysqli_query($conn, "INSERT INTO bantuan (nama_bantuan, penerima, tanggal)
                         VALUES('$nama', '$penerima', '$tanggal')");

    header("Location: bantuan.php");
    exit;
}

// =============== UPDATE DATA ===============
if (isset($_POST['update'])) {
    $id         = $_POST['id'];
    $nama       = $_POST['nama_bantuan'];
    $penerima   = $_POST['penerima'];
    $tanggal    = $_POST['tanggal'];

    mysqli_query($conn, "UPDATE bantuan SET 
                        nama_bantuan='$nama', 
                        penerima='$penerima', 
                        tanggal='$tanggal'
                        WHERE id='$id'");

    header("Location: bantuan.php");
    exit;
}

// =============== AMBIL DATA UNTUK EDIT ===============
$edit = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM bantuan WHERE id='$id'"));
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>CRUD Bantuan</title>
</head>
<body>

<h2>Data Bantuan</h2>

<table border="1" cellpadding="8">
<tr>
    <th>No</th>
    <th>Nama Bantuan</th>
    <th>Penerima</th>
    <th>Tanggal</th>
    <th>Aksi</th>
</tr>

<?php
$no = 1;
$data = mysqli_query($conn, "SELECT * FROM bantuan");
while ($row = mysqli_fetch_assoc($data)) {
?>
<tr>
    <td><?= $no++; ?></td>
    <td><?= $row['nama_bantuan']; ?></td>
    <td><?= $row['penerima']; ?></td>
    <td><?= $row['tanggal']; ?></td>
    <td>
        <a href="bantuan.php?edit=<?= $row['id']; ?>">Edit</a> |
        <a href="bantuan.php?hapus=<?= $row['id']; ?>" onclick="return confirm('Yakin?')">Hapus</a>
    </td>
</tr>
<?php } ?>
</table>

<hr>

<!-- =============== FORM TAMBAH =============== -->
<?php if (!$edit) { ?>
<h3>Tambah Bantuan</h3>
<form method="POST">
    Nama Bantuan: <input type="text" name="nama_bantuan" required><br><br>
    Penerima:     <input type="text" name="penerima" required><br><br>
    Tanggal:      <input type="date" name="tanggal" required><br><br>

    <button type="submit" name="simpan">Simpan</button>
</form>

<?php } ?>

<!-- =============== FORM EDIT =====
