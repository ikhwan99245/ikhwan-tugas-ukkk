<?php
require_once 'koneksi.php';
// fetch recent reports for display (limit 10)
$stmt = $conn->prepare("SELECT id, nama, jenis, lokasi, deskripsi, kontak, waktu FROM laporan ORDER BY waktu DESC LIMIT 10");
$stmt->execute();
$result_reports = $stmt->get_result();
$reports = $result_reports->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Layanan Masyarakat — Pelaporan</title>
  <style>
    body{font-family:Arial,Helvetica,sans-serif;background:#f3f6fb;color:#0b1220;margin:0;padding:20px}
    .container{max-width:900px;margin:0 auto}
    header{display:flex;justify-content:space-between;align-items:center}
    .card{background:white;padding:16px;border-radius:10px;box-shadow:0 6px 20px rgba(2,6,23,0.06);margin-top:14px}
    label{display:block;margin-top:8px;font-weight:600}
    input,textarea,select{width:100%;padding:10px;border-radius:8px;border:1px solid #d6e3ef;margin-top:6px}
    .btn{display:inline-block;padding:10px 14px;border-radius:8px;text-decoration:none;background:#0ea5a0;color:white;border:none;cursor:pointer}
    .muted{color:#6b7280;font-size:14px}
    .small{font-size:13px;color:#6b7280}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    td,th{padding:8px;border-bottom:1px solid #eef3f7;text-align:left}
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div>
        <h1>Layanan Masyarakatx   </h1>
        <div class="small muted">Sistem pelaporan & pendaftaran relawan</div>
      </div>
      <div>
        <a class="btn" href="admin.php">Halaman Admin</a>
      </div>
    </header>

    <?php if(isset($_GET['ok']) && $_GET['ok']=='lapor'): ?>
      <div class="card" style="border-left:4px solid #10b981">Laporan berhasil dikirim.</div>
    <?php endif; ?>
    <?php if(isset($_GET['ok']) && $_GET['ok']=='vol'): ?>
      <div class="card" style="border-left:4px solid #10b981">Pendaftaran relawan berhasil dikirim.</div>
    <?php endif; ?>

    <section class="card" aria-labelledby="lapor-title">
      <h2 id="lapor-title">Form Pelaporan Masalah</h2>
      <p class="muted small">Isi detail masalah di lingkungan (contoh: jalan rusak, kebocoran, lampu mati, sampah menumpuk).</p>
      <form action="proses_lapor.php" method="post">
        <label for="nama">Nama (boleh anonim)</label>
        <input type="text" name="nama" id="nama" maxlength="100" placeholder="Nama (opsional)">

        <label for="jenis">Kategori</label>
        <select name="jenis" id="jenis">
          <option value="Jalan Rusak">Jalan Rusak</option>
          <option value="Sampah">Sampah</option>
          <option value="Listrik">Listrik</option>
          <option value="Kebersihan">Kebersihan</option>
          <option value="Lainnya">Lainnya</option>
        </select>

        <label for="lokasi">Lokasi</label>
        <input type="text" name="lokasi" id="lokasi" required placeholder="Contoh: Jl. Merpati RT 02 RW 05">

        <label for="deskripsi">Deskripsi</label>
        <textarea name="deskripsi" id="deskripsi" required placeholder="Jelaskan masalah secara singkat"></textarea>

        <label for="kontak">Kontak (opsional)</label>
        <input type="text" name="kontak" id="kontak" maxlength="100" placeholder="Nomor/Email (opsional)">

        <div style="margin-top:12px">
          <button class="btn" type="submit">Kirim Laporan</button>
        </div>
      </form>
    </section>

    <section class="card">
      <h3>Daftar Laporan Terbaru</h3>
      <?php if(count($reports)===0): ?>
        <div class="muted small">Belum ada laporan.</div>
      <?php else: ?>
        <table>
          <thead><tr><th>Waktu</th><th>Kategori</th><th>Lokasi</th><th>Deskripsi</th></tr></thead>
          <tbody>
            <?php foreach($reports as $r): ?>
            <tr>
              <td class="small muted"><?php echo htmlspecialchars($r['waktu']); ?></td>
              <td><?php echo htmlspecialchars($r['jenis']); ?></td>
              <td><?php echo htmlspecialchars($r['lokasi']); ?></td>
              <td><?php echo nl2br(htmlspecialchars($r['deskripsi'])); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </section>

    <section class="card">
      <h3>Daftar Relawan</h3>
      <form action="proses_relawan.php" method="post" style="margin-bottom:12px">
        <label for="vname">Nama</label>
        <input type="text" name="nama" id="vname" required placeholder="Nama lengkap">
        <label for="vkontak">Kontak</label>
        <input type="text" name="kontak" id="vkontak" required placeholder="Nomor/Email">
        <div style="margin-top:10px">
          <button class="btn" type="submit">Daftar Relawan</button>
        </div>
      </form>
      <div class="small muted">Untuk melihat daftar relawan, buka halaman <a href="admin.php">Admin</a>.</div>
    </section>

    <footer style="margin-top:20px;text-align:center;color:#64748b">© 2025 Layanan Masyarakat — Prototype</footer>
  </div>
</body>
</html>
